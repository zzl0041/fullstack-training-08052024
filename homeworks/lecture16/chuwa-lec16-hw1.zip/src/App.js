import "./styles.css";
import store from "./store.js";
import { useState, useEffect } from "react";
import { Provider } from "react-redux";

export default function App() {
  const [todos, setTodos] = useState({});
  const [todoInput, setTodoInput] = useState("");
  const [remaining, setRemaining] = useState(0);

  useEffect(() => {
    const unsubscribe = store.subscribe(() => {
      // when todos are updated, update remaining as well
      setRemaining(
        Object.values(store.getState().todoList).filter((checked) => !checked)
          .length
      );
      setTodos(store.getState().todoList);
    });
    return () => {
      unsubscribe();
    };
  }, []);

  const addTodo = (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      store.dispatch({ type: "addTodo", todoName: todoInput });
      setTodoInput("");
    }
  };

  const clearCompletedTodoList = () => {
    store.dispatch({ type: "clearCompletedTodoList" });
  };

  const markAllCompleted = () => {
    store.dispatch({ type: "markAllCompleted" });
  };

  const checkTodo = (e) => {
    store.dispatch({ type: "checkTodo", todoName: e.target.value });
  };

  return (
    <Provider store={store}>
      <div className="App">
        <h1>Todos with Vite + React + TypeScript</h1>
        <div>
          <form>
            <label htmlFor="todo">add a todo to todo list: </label>
            <input
              type="text"
              name="todo"
              value={todoInput}
              onChange={(e) => setTodoInput(e.target.value)}
              onKeyDown={addTodo}
            />
          </form>
          <p>remaining {remaining} tasks</p>
          <form onSubmit={(e) => e.preventDefault()}>
            <button onClick={clearCompletedTodoList}>
              clear completed todos
            </button>
            <button onClick={markAllCompleted}>mark all todos completed</button>
            {Object.entries(todos).map(([todo, checked]) => (
              <div key={todo}>
                <label htmlFor={todo}>{todo}</label>
                <input
                  type="checkbox"
                  name={todo}
                  value={todo}
                  onChange={checkTodo}
                  checked={checked}
                />
              </div>
            ))}
          </form>
        </div>
      </div>
    </Provider>
  );
}
