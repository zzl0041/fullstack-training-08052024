const {
  configureStore,
  createReducer,
  createAction,
  createSlice,
} = require("@reduxjs/toolkit");

const initialState = {
  todoList: {},
};

const addTodo = createAction("addTodo");
const clearCompletedTodoList = createAction("clearCompletedTodoList");
const markAllCompleted = createAction("markAllCompleted");
const checkTodo = createAction("checkTodo");

const reducer = createReducer(initialState, (builder) => {
  builder
    .addCase(addTodo, (state, action) => ({
      ...state,
      todoList: { ...state.todoList, [action.todoName]: false },
    }))
    .addCase(clearCompletedTodoList, (state, action) => ({
      ...state,
      todoList: Object.fromEntries(
        Object.entries(state.todoList).filter(([todoName, checked]) => !checked)
      ),
    }))
    .addCase(markAllCompleted, (state, action) => ({
      ...state,
      todoList: Object.fromEntries(
        Object.keys(state.todoList).map((todoName) => [todoName, true])
      ),
    }))
    .addCase(checkTodo, (state, action) => ({
      ...state,
      todoList: {
        ...state.todoList,
        [action.todoName]: !state.todoList[action.todoName],
      },
    }));
});

const store = configureStore({ reducer });

export default store;
