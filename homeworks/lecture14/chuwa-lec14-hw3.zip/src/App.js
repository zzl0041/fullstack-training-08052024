import "./styles.css";
import React from "react";

// I did function component in lec13 hw1

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      todos: {},
      todoInput: "",
      remaining: 0,
    };
  }

  componentDidUpdate(prevProps, prevState) {
    if (JSON.stringify(prevState.todos) !== JSON.stringify(this.state.todos)) {
      this.setState({
        remaining: Object.entries(this.state.todos).reduce(
          (acc, [todoName, checked]) => acc + !checked,
          0
        ),
      });
    }
  }

  addTodo = (name) => {
    // if no existing todo
    if (!Object.keys(this.state.todos).some((todoName) => todoName === name)) {
      this.setState({ todos: { ...this.state.todos, [name]: false } });
    }
  };

  handleFormSubmit = (e) => {
    if (e.key === "Enter") {
      this.addTodo(this.state.todoInput);
      this.setState({ todoInput: "" });
    }
  };

  handleCheckChange = (e) => {
    this.setState({
      todos: { ...this.state.todos, [e.target.name]: e.target.checked },
    });
  };

  handleCheckAll = (e) => {
    this.setState({
      todos: Object.keys(this.state.todos).reduce((acc, todoName) => {
        acc[todoName] = e.target.checked;
        return acc;
      }, {}),
    });
  };

  handleClearChecked = () => {
    this.setState({
      todos: Object.entries(this.state.todos).reduce(
        (acc, [todoName, checked]) => {
          if (!checked) acc[todoName] = checked;
          return acc;
        },
        {}
      ),
    });
  };

  render() {
    return (
      <div className="App">
        <p>Todos with class component</p>
        <p>{this.state.remaining} remaining</p>
        <form
          onSubmit={(e) => e.preventDefault()}
          onKeyDown={this.handleFormSubmit}
        >
          <input
            value={this.state.todoInput}
            onChange={(e) => this.setState({ todoInput: e.target.value })}
          />
          <label>
            <input type="checkbox" onChange={this.handleCheckAll} />
            Mark all done
          </label>
          <button onMouseDown={this.handleClearChecked}>
            Clear Completed Todos
          </button>
          {Object.entries(this.state.todos).map(([todoName, checked]) => (
            <label key={todoName}>
              <input
                type="checkbox"
                name={todoName}
                value={todoName}
                checked={checked}
                onChange={this.handleCheckChange}
              />
              {todoName}
            </label>
          ))}
        </form>
      </div>
    );
  }
}
