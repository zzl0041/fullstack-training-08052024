import { Component } from "react";
import { useState, useEffect, useRef } from "react";
import "./styles.css";

export default function App() {
  const [components, setComponents] = useState([]);
  const [colors, setColors] = useState([]);
  // this will be a string when update
  const [selectComponentId, setSelectComponentId] = useState("");
  const selectColor = useRef("");

  useEffect(() => {
    setComponents(
      ["first", "second", "third", "fourth", "fifth", "sixth"].map(
        (defaultName, idx) => ({ id: idx, name: defaultName, color: "" })
      )
    );
    setColors(["", "red", "green", "blue", "grey", "Aquamarine", "Brown"]);
  }, []);

  return (
    <div className="App">
      <div className="selections">
        <form>
          <select
            name="component-names"
            value={selectComponentId}
            onChange={(e) => setSelectComponentId(e.target.value)}
          >
            {components.map((component) => (
              <option key={component.id} value={component.id}>
                {component.name}
              </option>
            ))}
          </select>
        </form>
        <form>
          <select
            name="bg-colors"
            ref={selectColor}
            onChange={() => {
              const currentColor = selectColor.current.value;
              setComponents(
                components.map((prevComponent) =>
                  prevComponent.id === +selectComponentId
                    ? { ...prevComponent, color: currentColor }
                    : prevComponent
                )
              );
            }}
          >
            {colors.map((color) => (
              <option key={color} value={color}>
                {color}
              </option>
            ))}
          </select>
        </form>
      </div>

      <div className="components-container">
        {components.map((component) => (
          // assume number of components will not change
          <div
            key={component.id}
            className="component"
            style={{ backgroundColor: component.color }}
          >
            <form>
              <label htmlFor={component.id}>Component name: </label>
              <input
                name={component.id}
                value={component.name}
                onChange={(e) =>
                  setComponents(
                    components.map((prevComponent) =>
                      prevComponent.id === component.id
                        ? { ...prevComponent, name: e.target.value }
                        : prevComponent
                    )
                  )
                }
              />
            </form>
          </div>
        ))}
      </div>
    </div>
  );
}
