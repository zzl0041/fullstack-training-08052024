import "./styles.css";
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// Dynamically importing components
const Home = React.lazy(() => import("./Home"));
const Login = React.lazy(() => import("./Login"));
const Users = React.lazy(() => import("./Users"));
const NoMatch = React.lazy(() => import("./NoMatch"));

export default function App() {
  return (
    <div className="App">
      <Router>
        <React.Suspense fallback={<div>Loading...</div>}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="login" element={<Login />} />
            <Route path="users" element={<Users />} />
            <Route path="*" element={<NoMatch />} />
          </Routes>
        </React.Suspense>
      </Router>
    </div>
  );
}
