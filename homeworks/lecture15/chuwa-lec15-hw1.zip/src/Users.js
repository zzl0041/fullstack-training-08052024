import "./users-styles.css";
import { useState, useEffect } from "react";
import store from "./store.js";
import { useNavigate, useLocation } from "react-router-dom";

function UsersDisplay({ users, setCurrentUserUrl }) {
  return (
    <div className="users-display">
      <table>
        <thead>
          <tr>
            <th>id</th>
            <th>username</th>
            <th>image</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user) => (
            <tr key={user.id}>
              <td>{user.id}</td>
              <td onClick={() => setCurrentUserUrl(user.url)}>{user.login}</td>
              <td>
                <img src={user.avatar_url} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function UserCardDisplay({ currentUserUrl }) {
  const [user, setUser] = useState({});
  useEffect(() => {
    // when DidUpdate
    (async function getUser(url) {
      try {
        // get user info
        const response = await fetch(url);
        if (!response.ok) {
          throw new Error(`Response status: ${response.status}`);
        }
        const user = await response.json();
        const { name, location, avatar_url, repos_url } = user;
        // get 3 repo links
        const response2 = await fetch(repos_url);
        if (!response2.ok) {
          throw new Error(`Response status: ${response2.status}`);
        }
        const repos = await response2.json();
        const top3Repos = repos
          .slice(0, 3)
          .map(({ name, html_url, description }) => ({
            name,
            html_url,
            description,
          }));
        setUser({ name, location, avatar_url, top3Repos });
      } catch (error) {
        console.error(error.message);
      }
    })(currentUserUrl);
  }, [currentUserUrl]);

  return (
    <div className="user-card-display">
      {Object.keys(user).length === 0 ? (
        <div></div>
      ) : (
        <div className="user-card">
          <div className="avatar-field">
            <img src={user.avatar_url} />
          </div>
          <div className="info-field">
            <h2>{user.name}</h2>
            <p>Location: {user.location}</p>
            <p>Repositories: </p>
            <ul>
              {user.top3Repos?.map((repo) => (
                <li key={repo.html_url}>
                  <a href={repo.html_url}>{repo.name}</a>
                  <p>{repo.description}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}

export default function Users() {
  const [users, setUsers] = useState([]);
  const [currentUserUrl, setCurrentUserUrl] = useState("");

  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // validate login
    if (!store.getState().user) {
      console.log(location);
      navigate("/login", { state: { from: location } });
    }
    // when didmount get users
    (async function getUsers(url) {
      try {
        const response = await fetch(url);
        if (!response.ok) {
          throw new Error(`Response status: ${response.status}`);
        }
        const users = await response.json();
        setUsers(users);
      } catch (error) {
        console.error(error.message);
      }
    })("https://api.github.com/users");
  }, []);

  return (
    <div className="Users">
      <UsersDisplay
        users={users}
        setCurrentUserUrl={(url) => setCurrentUserUrl(url)}
      />
      <UserCardDisplay currentUserUrl={currentUserUrl} />
    </div>
  );
}
