import "./styles.css";
import React from "react";
import store from "./store.js";
import { Navigate, useLocation, Link } from "react-router-dom";

export default function Home() {
  const location = useLocation();

  return (
    <div>
      <h1>Home Page</h1>
      <Link to="/login" state={{ from: location }}>
        {store.getState().user ? <p>logout</p> : <p>login</p>}
      </Link>
    </div>
  );
}
