import "./styles.css";
import store from "./store.js";
import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  // previous route
  const from = location.state?.from?.pathname || "/";

  useEffect(() => {
    // if already login, log out the user
    console.log(from);
    console.log(location);
    if (store.getState().user) {
      store.dispatch({ type: "LOGOUT" });
      navigate(from, { replace: true });
    }
  }, []);

  // login
  const handleLogin = (e) => {
    e.preventDefault();
    // mock login
    if (e.target.password.value === "123456") {
      store.dispatch({ type: "LOGIN", username: e.target.username.value });
      // back to previous route
      navigate(from, { replace: true });
    } else {
      alert("login failed, please try again");
    }
  };
  return (
    <div className="login">
      <form onSubmit={handleLogin}>
        <label htmlFor="username">username</label>
        <input name="username" />
        <br />
        <label htmlFor="password">password</label>
        <input name="password" type="password" />
        <br />
        <button>submit</button>
      </form>
    </div>
  );
}
