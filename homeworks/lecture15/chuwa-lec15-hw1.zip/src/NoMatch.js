import React from "react";

export default function NoMatch() {
  return <h1>404 Not Found</h1>;
}
