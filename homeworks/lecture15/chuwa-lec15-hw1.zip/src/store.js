const {
  configureStore,
  createReducer,
  createAction,
  createSlice,
} = require("@reduxjs/toolkit");

const initialState = {
  user: null,
};

const LOGIN = createAction("LOGIN");
const LOGOUT = createAction("LOGOUT");

const reducer = createReducer(initialState, (builder) => {
  builder
    .addCase(LOGIN, (state, action) => ({
      ...state,
      user: action.username,
    }))
    .addCase(LOGOUT, (state, action) => ({
      ...state,
      user: null,
    }));
});

const store = configureStore({ reducer });

export default store;
